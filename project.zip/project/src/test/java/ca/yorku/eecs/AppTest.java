package ca.yorku.eecs;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit The test for simple App.
 */
public class AppTest extends TestCase
{
	
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest(String testName)
    {
        super(testName);
    }
    

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite(AppTest.class);
    }

    /**
     * Rigorous Test :-)
     */
    public void testApp()
    {
        assertTrue(true);
    }
    
    
    /**
     * Here we set up all the variables needed to conduct the test cases
     * This method will be called before each test
     */
    protected void setUp() {
        // Ensure that the database connection is established
        if (Utils.driver == null) {
            Connect connect = new Connect();
            Utils.driver = connect.getDriver();
        }
    }
  
    /**
     * The test for successful actor addition (200 OK)
     */
    public void testAddActorPass() {
        try {
            // Here we create an example JSON body
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nm0000542");
            reqBody.put("name", "Keanu Reeves");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Finally, we call the method and assert the result
            AddActor addActor = new AddActor();
            String[] result = addActor.handlePut(requestBody); // Call handlePut and get the result
            int statusCode = Integer.parseInt(result[0]); // Extract the status code from the result

            // Assert that the status code is 200
            assertTrue(statusCode == 200);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false); // Fail the test if an exception is thrown
        }
    }

    /**
     * The test for failed actor addition (400 FAIL)
     */
    public void testAddActorFail() {
        try {
            // Here we create an example JSON body with missing "actorId"
            JSONObject reqBody = new JSONObject();
            reqBody.put("name", "Tom Hanks");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Finally, we call the method and assert the result
            AddActor addActor = new AddActor();
            String[] result = addActor.handlePut(requestBody); // Call handlePut and get the result
            int statusCode = Integer.parseInt(result[0]); // Extract the status code from the result

            // Assert that the status code is 400
            assertTrue(statusCode == 400);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false); // Fail the test if an exception is thrown
        }
    }

    /**
     * The test for successful movie addition (200 OK)
     */
    public void testAddMoviePass() {
        try {
            // Here we create an example JSON body
            JSONObject reqBody = new JSONObject();
            reqBody.put("movieId", "nm7001632");
            reqBody.put("name", "Fight Club");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Finally we call the method and assert the result
            AddMovie addMovie = new AddMovie();
            String[] result = addMovie.handlePut(requestBody); // Call the method and get the values

            // Extract the status code and response
            int statusCode = Integer.parseInt(result[0]);
//            String response = result[1];

            assertTrue(statusCode == 200); // Assert that the status code is 200
//      no need assertTrue(response.contains("Movie created successfully.") || response.contains("Movie already exists with matching name.")); // Verify the response message

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for failed movie addition (400 FAIL)
     */
    public void testAddMovieFail() {
        try {
            // Here we create an example JSON body with missing "movieId"
            JSONObject reqBody = new JSONObject();
            reqBody.put("name", "Forrest Gump");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Finally we call the method and assert the result
            AddMovie addMovie = new AddMovie();
            String[] result = addMovie.handlePut(requestBody); // Call the method to get the values

            // Extract the status code and response
            int statusCode = Integer.parseInt(result[0]);
//            String response = result[1];

            assertTrue(statusCode == 400); // Assert that the status code is 400

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for successful relationship addition (200 OK)
     */
    public void testAddRelationshipPass() { 
        try {
            // Here we create an example JSON body
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nm0000216");
            reqBody.put("movieId", "nm7001987");

            // Convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the method and assert the result
            AddRelationship addRelationship = new AddRelationship();
            String[] result = addRelationship.handlePut(requestBody);
            int statusCode = Integer.parseInt(result[0]);
            assertTrue(statusCode == 200);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for failed relationship addition (400/404 FAIL)
     */
    public void testAddRelationshipFail() {
        try {
            // Create an example JSON body missing "movieId" to simulate failure
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nm0000542");

            // Convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the method and assert the result
            AddRelationship addRelationship = new AddRelationship();
            String[] result = addRelationship.handlePut(requestBody);
            int statusCode = Integer.parseInt(result[0]);
            assertTrue(statusCode == 400 || statusCode == 404);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    
   
    
    /**
     * The test for successful actor retrieval (200 OK)
     */
    public void testGetActorPass() {
        try {
            // Create an example JSON body
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nm0000542");

            // Convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method and assert the result
            GetActor getActor = new GetActor();
            String[] result = getActor.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]);

            // Assert the status code is 200
            assertTrue(statusCode == 200);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for failed actor retrieval (400/404 FAIL)
     */
    public void testGetActorFail() {
        try {
            // Create an example JSON body missing "actorId" to simulate failure
            JSONObject reqBody = new JSONObject();

            // Convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method and assert the result
            GetActor getActor = new GetActor();
            String[] result = getActor.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]);

            // Assert the status code is 400 or 404
            assertTrue(statusCode == 400 || statusCode == 404);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }
    
    /**
     * The test for successful movie retrieval (200 OK)
     */
    public void testGetMoviePass() {
        try {
            // Here we create an example JSON body with a valid movieId
            JSONObject reqBody = new JSONObject();
            reqBody.put("movieId", "nm7001987");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method and retrieve the result
            GetMovie getMovie = new GetMovie();
            String[] result = getMovie.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]);

            // Assert that the status code is 200 and the response is not empty
            assertTrue(statusCode == 200);
            assertFalse(result[1].isEmpty());

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for failed movie retrieval (400/404 FAIL)
     */
    public void testGetMovieFail() {
        try {
            // Here we create an example JSON body with a non-existent or invalid movieId
            JSONObject reqBody = new JSONObject();
            reqBody.put("movieId", "randommoviename");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method and retrieve the result
            GetMovie getMovie = new GetMovie();
            String[] result = getMovie.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]);

            // Expecting either 400 BAD REQUEST or 404 NOT FOUND, and response should be empty
            assertTrue(statusCode == 400 || statusCode == 404);
            assertTrue(result[1].isEmpty());

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for successful relationship check (200 OK)
     */
    public void testHasRelationshipPass() {
        try {
            // Create an example JSON body with valid actorId and movieId
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nm0000763");
            reqBody.put("movieId", "nm7001987");

            // Convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method and get the result
            HasRelationship hasRelationship = new HasRelationship();
            String[] result = hasRelationship.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]); // Get the status code from the result

            // Assert that the status code is 200
            assertTrue(statusCode == 200);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for failed relationship check (400/404 FAIL)
     */
    public void testHasRelationshipFail() {
        try {
            // Create an example JSON body with a missing actorId or movieId
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nonExistentActorId");
            reqBody.put("movieId", "nonExistentMovieId");

            // Convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method and get the result
            HasRelationship hasRelationship = new HasRelationship();
            String[] result = hasRelationship.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]); // Get the status code from the result

            // Expecting either 400 BAD REQUEST or 404 NOT FOUND
            assertTrue(statusCode == 400 || statusCode == 404);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for successful Bacon Number computation (200 OK)
     */
    public void testComputeBaconNumberPass() {
        try {
            // Here we create an example JSON body with a valid actorId
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nm1001213");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method in ComputeBaconNumber and get the result
            ComputeBaconNumber computeBaconNumber = new ComputeBaconNumber();
            String[] result = computeBaconNumber.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]);

            // Assert that the status code is 200
            assertTrue(statusCode == 200);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    /**
     * The test for failed Bacon Number computation (400/404 FAIL)
     */
    public void testComputeBaconNumberFail() {
        try {
            // Here we create an example JSON body with an invalid actorId or no actorId
            JSONObject reqBody = new JSONObject();

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method in ComputeBaconNumber and get the result
            ComputeBaconNumber computeBaconNumber = new ComputeBaconNumber();
            String[] result = computeBaconNumber.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]);

            // Assert that the status code is either 400 or 404
            assertTrue(statusCode == 400 || statusCode == 404);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }
    
    public void testComputeBaconPathPass() {
        try {
            // Here we create an example JSON body with a valid actorId
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "nm1001213");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method of ComputeBaconPath and assert the result
            ComputeBaconPath computeBaconPath = new ComputeBaconPath();
            String[] result = computeBaconPath.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
            assertTrue(statusCode == 200);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    public void testComputeBaconPathFail() {
        try {
            // Here we create an example JSON body with an invalid actorId
            JSONObject reqBody = new JSONObject();
            reqBody.put("actorId", "invalidActorId123");

            // Then we convert the JSON into a string for the request body
            String requestBody = reqBody.toString();

            // Call the handleGet method of ComputeBaconPath and assert the result
            ComputeBaconPath computeBaconPath = new ComputeBaconPath();
            String[] result = computeBaconPath.handleGet(requestBody);
            int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
            assertTrue(statusCode == 404 || statusCode == 400);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

      
    
    
}
