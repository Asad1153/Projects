package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/**
 * EXTRA FEATURE
 * This class processes an HTTP GET request to filter movies by a specified award
 */
public class FilterByAward implements HttpHandler {

    public FilterByAward() {}

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("GET")) { //Get request only
                handleGet(r);
            } else {
                r.sendResponseHeaders(404, -1); //Respond with 404 if not get
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles the GET request to filter movies by award
     * @param r HttpExchange object representing the HTTP request and response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public void handleGet(HttpExchange r) throws IOException, JSONException {
        
        String body = Utils.convert(r.getRequestBody()); //Req body in json
        JSONObject deserialized = new JSONObject(body);

        String award = null;
        if (deserialized.has("award")) {
            award = deserialized.getString("award"); //Get the award from the req
        } else {
            r.sendResponseHeaders(400, -1); //If not 400 bad request
            return;
        }

        String response = null;
        int statusCode;

        try (Session session = Utils.driver.session()) { // Start the session
            String query;
            query = "MATCH (m:movie) WHERE $award IN m.awards "
                  + "RETURN {movieId: m.movieId, name: m.name, awards: m.awards} AS res ORDER BY m.name ASC"; //Cypher query

            StatementResult result = session.run(query, parameters("award", award));

            JSONArray movies = new JSONArray();
            while (result.hasNext()) {
                Record record = result.next();
                JSONObject movie = new JSONObject(record.get("res").asMap()); //Find movies with designated filter
                movies.put(movie);
            }

            if (movies.length() > 0) {
                response = movies.toString();
                statusCode = 200; //If the movie exists send 200 else 400
            } else {
                statusCode = 404;
                response = "";
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage());
            statusCode = 500;
            response = e.getMessage();
        }

        r.sendResponseHeaders(statusCode, response.length());
        OutputStream os = r.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}
