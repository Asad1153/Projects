package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Transaction;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/**
 * This class handles HTTP GET requests to check if a relationship exists between an actor and a movie in the Neo4j database
 */
public class HasRelationship implements HttpHandler {

    public HasRelationship() {}

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("GET")) { // Only handle GET requests
                String requestBody = Utils.convert(r.getRequestBody());
                String[] result = handleGet(requestBody);
                int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
                String response = result[1]; // Get the response body from the result
                r.sendResponseHeaders(statusCode, response.length());

                // Write the response body back to the client
                try (OutputStream os = r.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                r.sendResponseHeaders(404, -1); // Send status code 404 if the request is not a GET
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles the GET request to check if a relationship exists between an actor and a movie.
     * @param requestBody String representing the HTTP request body
     * @return String[] with status code and response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public String[] handleGet(String requestBody) throws IOException, JSONException {
        
        String actorId = "";
        String movieId = "";
        JSONObject deserialized = new JSONObject(requestBody); // Convert the body to a JSON object

        if (deserialized.has("actorId")) {
            actorId = deserialized.getString("actorId"); // Get actorId 
        } else {
            return new String[] {"400", ""}; // Return status 400 if actorId is not provided
        }

        if (deserialized.has("movieId")) {
            movieId = deserialized.getString("movieId"); // Get movieId 
        } else {
            return new String[] {"400", ""}; // Return status 400 if movieId is not provided
        }

        String response = "";
        int statusCode;

        try (Session session = Utils.driver.session()) {
            try (Transaction tx = session.beginTransaction()) {
                // Check if the actor exists
                StatementResult actorResult = tx.run("MATCH (a:actor {actorId: $actorId}) RETURN a", parameters("actorId", actorId)); // Cypher query
                if (!actorResult.hasNext()) {
                    return new String[] {"404", ""}; // Return 404 if actor is not found
                } else {
                    // Check if the movie exists
                    StatementResult movieResult = tx.run("MATCH (m:movie {movieId: $movieId}) RETURN m", parameters("movieId", movieId)); // Cypher query
                    if (!movieResult.hasNext()) {
                        return new String[] {"404", ""}; // Return 404 if movie is not found
                    } else {
                        // Check if the relationship exists
                        StatementResult result = tx.run("MATCH (a:actor {actorId: $actorId})-[r:ACTED_IN]->(m:movie {movieId: $movieId}) "
                                + "RETURN {actorId: a.actorId, movieId: m.movieId, hasRelationship: true} AS res",
                                parameters("actorId", actorId, "movieId", movieId)); // Cypher query
                        if (result.hasNext()) {
                            Record record = result.next();
                            JSONObject relationship = new JSONObject(record.get("res").asMap());
                            response = relationship.toString();
                            statusCode = 200; // Return 200 if relationship is found
                        } else {
                            JSONObject noRelationship = new JSONObject();
                            noRelationship.put("actorId", actorId);
                            noRelationship.put("movieId", movieId);
                            noRelationship.put("hasRelationship", false);
                            response = noRelationship.toString();
                            statusCode = 200; // Return 200 with no relationship
                        }
                    }
                }
                tx.success();
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage());
            statusCode = 500;
            response = e.getMessage();
        }

        return new String[] {String.valueOf(statusCode), response};
    }
}
