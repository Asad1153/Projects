package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Transaction;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/**
 * This class handles any HTTP GET requests to compute the Bacon Number for a given actor,
 * which is the number of degrees of separation between the actor and Kevin Bacon
 * in terms of movie roles
 */
public class ComputeBaconNumber implements HttpHandler {

    private static final String KEVIN_BACON_ID = "nm0000102"; // Kevin Bacon ID

    public ComputeBaconNumber() {}

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("GET")) { // Only handle GET requests
                String requestBody = Utils.convert(r.getRequestBody());
                String[] result = handleGet(requestBody);
                int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
                String response = result[1]; // Get the response body from the result
                r.sendResponseHeaders(statusCode, response.length());

                // Write the response body back to the client
                try (OutputStream os = r.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                r.sendResponseHeaders(404, -1); // Send status code 404 if the request is not a GET
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * This method processes the GET request to compute the Bacon Number of an actor.
     * It calculates the shortest path between the specified actor and Kevin Bacon
     * in the Neo4j database and returns the Bacon Number.
     * 
     * @param requestBody The request body as a String.
     * @return String[] with status code and response.
     * @throws IOException if there is an issue with the request or response.
     * @throws JSONException if there is an issue parsing the JSON from the request.
     */
    public String[] handleGet(String requestBody) throws IOException, JSONException {
        
        String actorId = "";
        JSONObject deserialized = new JSONObject(requestBody); // Convert the body to a JSON object
        if (deserialized.has("actorId")) { // If actorId is provided
            actorId = deserialized.getString("actorId");
        } else {
            return new String[] {"400", ""}; // Return status 400 if actorId is not provided
        }

        // Handle the case where the actorId is Kevin Bacon's own ID
        if (KEVIN_BACON_ID.equals(actorId)) {
            String response = new JSONObject().put("baconNumber", 0).toString();
            return new String[] {"200", response}; // Kevin Bacon has a Bacon Number of 0
        }

        String response = "";
        int statusCode;

        try (Session session = Utils.driver.session()) { // Start a session
            try (Transaction tx = session.beginTransaction()) { // Start the transaction
                StatementResult result = tx.run(
                    "MATCH p = shortestPath((a:actor {actorId: $actorId})-[:ACTED_IN*]-(b:actor {actorId: $kevinBaconId})) "
                    + "RETURN length(p) / 2 AS baconNumber",
                    parameters("actorId", actorId, "kevinBaconId", KEVIN_BACON_ID) // Cypher query
                );

                if (result.hasNext()) {
                    Record record = result.next();
                    int baconNumber = record.get("baconNumber").asInt();
                    response = new JSONObject().put("baconNumber", baconNumber).toString();
                    statusCode = 200; // If successful we return 200
                } else {
                    statusCode = 404; // If no path is found we return 404
                    response = "";
                }
                tx.success();
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage());
            statusCode = 500; // If an exception occurs we return 500
            response = e.getMessage();
        }

        return new String[] {String.valueOf(statusCode), response};
    }
}
