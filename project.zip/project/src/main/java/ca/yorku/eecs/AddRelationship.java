package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Transaction;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/*
 * This class processes an HTTP PUT request that adds a relationship between an actor and a movie to the database
 */
public class AddRelationship implements HttpHandler {

    public AddRelationship() {
    }

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("PUT")) { // Only for PUT requests
                String requestBody = Utils.convert(r.getRequestBody());
                String[] result = handlePut(requestBody);
                int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
                String response = result[1]; // Get the response body from the result
                r.sendResponseHeaders(statusCode, response.length());

                // Make sure to write the response body back to the client
                try (OutputStream os = r.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                r.sendResponseHeaders(404, -1); // Send status code of 404 if the request is not a PUT
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the PUT request that adds a relationship between an actor and a movie to the Neo4j database
     * @param requestBody is a String representing the HTTP request body
     * @return String[] with status code and response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public String[] handlePut(String requestBody) throws IOException, JSONException {
        // Convert the request body to a JSON object
        JSONObject deserialized = new JSONObject(requestBody);
        
        // Variables
        String actorId = "";
        String movieId = "";
        String response = "";
        int statusCode;

        // Validate and extract the "actorId" field
        if (deserialized.has("actorId")) {
            actorId = deserialized.getString("actorId"); // Get the actorId from the JSON
        } else {
            return new String[]{"400", ""}; // If there is no "actorId" we return 400 status code
        }

        // Validate and extract the "movieId" field
        if (deserialized.has("movieId")) {
            movieId = deserialized.getString("movieId"); // Get movieId from JSON
        } else {
            return new String[]{"400", ""}; // If there is no "movieId" we return 400 status code
        }

        try (Session session = Utils.driver.session()) {
            // Start a transaction for the queries
            try (Transaction tx = session.beginTransaction()) {
                // Check if actor exists
                StatementResult actorResult = tx.run("MATCH (a:actor {actorId: $actorId}) RETURN a", 
                                                      parameters("actorId", actorId));
                if (!actorResult.hasNext()) {
                    return new String[]{"404", "Actor not found"}; // Actor not found we return 404
                } else {
                    // Check if movie exists
                    StatementResult movieResult = tx.run("MATCH (m:movie {movieId: $movieId}) RETURN m", 
                                                          parameters("movieId", movieId));
                    if (!movieResult.hasNext()) {
                        return new String[]{"404", "Movie not found"}; // Movie not found we return 404
                    } else {
                        // Check if relationship already exists
                        StatementResult relationshipResult = tx.run("MATCH (a:actor {actorId: $actorId})-[r:ACTED_IN]->(m:movie {movieId: $movieId}) RETURN r", 
                                                                     parameters("actorId", actorId, "movieId", movieId));
                        if (relationshipResult.hasNext()) {
                            return new String[]{"400", "Relationship already exists"}; // Relationship already exists return 400
                        } else {
                            tx.run("MATCH (a:actor {actorId: $actorId}), (m:movie {movieId: $movieId}) " +
                                   "MERGE (a)-[:ACTED_IN]->(m)", parameters("actorId", actorId, "movieId", movieId));
                            statusCode = 200; // Relationship created return 200
                            response = "Relationship created successfully.";
                        }
                    }
                }
                tx.success();
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage()); // Log exception and return 500 status code
            return new String[]{"500", e.getMessage()};
        }

        return new String[]{String.valueOf(statusCode), response};
    }
}
