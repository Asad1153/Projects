package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;

import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.Transaction;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/*
 * This class processes an HTTP PUT request that adds actors to the database.
 */
public class AddActor implements HttpHandler {

    public AddActor() {
    }

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("PUT")) { // only for the PUT requests
                String body = Utils.convert(r.getRequestBody());  // We convert request body to string
                String[] result = handlePut(body);  // Pass the string body to the method
                int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
                String response = result[1]; // Get the response body from the result
                r.sendResponseHeaders(statusCode, response.length());

                // Write the response body back to the client
                try (OutputStream os = r.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                r.sendResponseHeaders(404, -1); // send status code of 404 if the request is not a PUT
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the logic of the PUT request that adds an actor to the Neo4j database.
     * @param body is a string representing the HTTP request body
     * @return String[] containing the status code and response body
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public String[] handlePut(String body) throws IOException, JSONException {
        // Convert the request body to a JSON object
        JSONObject deserialized = new JSONObject(body);
        
        // Variables
        int statusCode = 0;
        String response = "";
        String name = "";
        String actorId = "";

        // Validate and extract the "name" field
        if (deserialized.has("name")) {
            name = deserialized.getString("name"); // get name from the JSON
        } else {
            return new String[] {"400", ""}; // Check if there is no "name", return 400 status code
        }

        // Validate and extract the "actorId" field
        if (deserialized.has("actorId")) {
            actorId = deserialized.getString("actorId"); // get actorId from JSON
        } else {
            return new String[] {"400", ""}; // if there is no "actorId" we return 400 status code
        }

        try (Session session = Utils.driver.session()) {
            // Start a transaction for the queries
            try (Transaction tx = session.beginTransaction()) {
                // Check if actorId already exists
                StatementResult result = tx.run("MATCH (a:actor {actorId: $actorId}) RETURN a.name AS name", 
                                                parameters("actorId", actorId));
                if (result.hasNext()) {
                    Record record = result.next();
                    String existingName = record.get("name").asString();
                    if (!existingName.equals(name)) {
                        statusCode = 400; // if name is not the same return 400
                    } else {
                        statusCode = 200; // if name is the same return 200
                    }
                } else {
                    tx.run("CREATE (a:actor {actorId: $actorId, name: $name})",  // Cypher query
                           parameters("actorId", actorId, "name", name));
                    statusCode = 200; // successful query so we return 200
                }
                tx.success();
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage()); // log exception and return 500 status code
            statusCode = 500;
            response = e.getMessage(); // Include the error message in the response
        }

        return new String[] {String.valueOf(statusCode), response};
    }
}
