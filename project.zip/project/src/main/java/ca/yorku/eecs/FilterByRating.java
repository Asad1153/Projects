package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/**
 * This class handles HTTP GET requests to filter movies by a specified minimum rating
 */
public class FilterByRating implements HttpHandler {

    public FilterByRating() {}

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("GET")) { //Handle a get method
                handleGet(r);
            } else {
                r.sendResponseHeaders(404, -1); //Respond with 404 if not a get method
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles the GET request to filter movies by minimum rating
     * @param r HttpExchange object representing the HTTP request and response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public void handleGet(HttpExchange r) throws IOException, JSONException {
        
        String body = Utils.convert(r.getRequestBody()); //Convert the req body to a JSON objects
        JSONObject deserialized = new JSONObject(body);

        Float minRating = null;
        if (deserialized.has("minRating")) { //Get the minRating from JSON objects
            try {
                minRating = (float) deserialized.getDouble("minRating"); //Convert to float
            } catch (JSONException e) {
                r.sendResponseHeaders(400, -1); //If not given return 400
                return;
            }
        }

        String response = null;
        int statusCode;

        try (Session session = Utils.driver.session()) { //Start session
            String query;
            if (minRating != null) { //Cypher query depending on situations
                query = "MATCH (m:movie) WHERE m.rating >= $minRating RETURN {movieId: m.movieId, name: m.name, rating: m.rating} AS res ORDER BY m.rating DESC"; //if min rating is provided
            } else {
                query = "MATCH (m:movie) RETURN {movieId: m.movieId, name: m.name, rating: m.rating} AS res ORDER BY m.rating DESC"; //if it is not return movies in desc order
            }

            StatementResult result = session.run(query, parameters("minRating", minRating));

            JSONArray movies = new JSONArray();
            while (result.hasNext()) {
                Record record = result.next();
                JSONObject movie = new JSONObject(record.get("res").asMap());
                movies.put(movie);
            }

            if (movies.length() > 0) {
                response = movies.toString();
                statusCode = 200; //If response is valid return 200 else 400
            } else {
                statusCode = 404;
                response = "";
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage());
            statusCode = 500;
            response = e.getMessage();
        }

        r.sendResponseHeaders(statusCode, response.length());
        OutputStream os = r.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}
