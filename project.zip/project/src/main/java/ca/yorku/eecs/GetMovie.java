package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/**
 * This class handles HTTP GET requests to retrieve movie details from the Neo4j database.
 */
public class GetMovie implements HttpHandler {

    public GetMovie() {}

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("GET")) { // Only handle GET requests
                String body = Utils.convert(r.getRequestBody());
                String[] result = handleGet(body);
                int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
                String response = result[1]; // Get the response body from the result
                r.sendResponseHeaders(statusCode, response.length());

                // Write the response body back to the client
                try (OutputStream os = r.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                r.sendResponseHeaders(404, -1); // Send 404 if the request is not GET
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles the GET request to retrieve a movie's details.
     * @param requestBody String representing the HTTP request body
     * @return String[] with status code and response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public String[] handleGet(String requestBody) throws IOException, JSONException {
        
        String movieId = "";
        JSONObject deserialized = new JSONObject(requestBody); // Convert the body to a JSON object
        if (deserialized.has("movieId")) { // If movieId is provided
            movieId = deserialized.getString("movieId");
        } else {
            return new String[] {"400", ""}; // Return status 400 if movieId is not provided
        }

        String response = "";
        int statusCode;

        try (Session session = Utils.driver.session()) { // Start a session
            StatementResult result = session.run("MATCH (m:movie {movieId: $movieId}) OPTIONAL MATCH (a:actor)-[:ACTED_IN]->(m) "
                                                + "RETURN {movieId: m.movieId, name: m.name, actors: collect(a.actorId)} AS res", 
                                                parameters("movieId", movieId)); // Cypher query
            if (result.hasNext()) {
                Record record = result.next();
                JSONObject movie = new JSONObject(record.get("res").asMap());
                response = movie.toString();
                statusCode = 200; // If movie found, return 200
            } else {
                statusCode = 404; // If movie not found, return 404
                response = "";
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage());
            statusCode = 500;
            response = e.getMessage();
        }

        return new String[] {String.valueOf(statusCode), response};
    }
}
