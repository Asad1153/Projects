package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;

import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Transaction;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/*
 *  This class processes an HTTP PUT request that adds movies to the database
 */
public class AddMovie implements HttpHandler {

    public AddMovie() {
    }

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("PUT")) { // only for PUT requests
                String requestBody = Utils.convert(r.getRequestBody());
                String[] result = handlePut(requestBody);
                int statusCode = Integer.parseInt(result[0]); // Get the status code from the result and make sure to parse it
                String response = result[1]; // Get the response body from the result
                r.sendResponseHeaders(statusCode, response.length());

                // Write the response body back to the client
                try (OutputStream os = r.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                r.sendResponseHeaders(404, -1); // send status code of 404 if the request is not a PUT
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles the PUT request that adds a movie to the Neo4j database
     * @param requestBody is a String representing the HTTP request body
     * @return a String array with the status code and the response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public String[] handlePut(String requestBody) throws IOException, JSONException {
        // Convert the request body to a JSON object
        JSONObject deserialized = new JSONObject(requestBody);
        
        // Variables
        String name = "";
        String movieId = "";

        // Validate and extract the "name" field
        if (deserialized.has("name")) {
            name = deserialized.getString("name"); // get name from JSON
        } else {
            return new String[] {"400", ""}; // if there is no "name" we return 400 status code
        }

        // Validate and extract the "movieId" field
        if (deserialized.has("movieId")) {
            movieId = deserialized.getString("movieId"); // get movieId from JSON
        } else {
            return new String[] {"400", ""}; // if there is no "movieId" we return 400 status code
        }

        String response = "";
        int statusCode;

        try (Session session = Utils.driver.session()) {
            // Start a transaction for the queries
            try (Transaction tx = session.beginTransaction()) {
                // Check if movieId already exists
                StatementResult result = tx.run("MATCH (m:movie {movieId: $movieId}) RETURN m.name AS name", 
                                                parameters("movieId", movieId));
                if (result.hasNext()) {
                    Record record = result.next();
                    String existingName = record.get("name").asString();
                    if (!existingName.equals(name)) {
                        statusCode = 400; // if name is not the same return 400
                        response = "Movie name does not match existing record.";
                    } else {
                        statusCode = 200; // if name is the same return 200
                        response = "Movie already exists with matching name.";
                    }
                } else {
                    tx.run("CREATE (m:movie {movieId: $movieId, name: $name})",  // Cypher query
                           parameters("movieId", movieId, "name", name));
                    statusCode = 200; // successful query return 200
                    response = "Movie created successfully.";
                }
                tx.success();
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage()); // log exception and return 500 status code
            statusCode = 500;
            response = e.getMessage();
        }

        return new String[] {String.valueOf(statusCode), response};
    }
}
