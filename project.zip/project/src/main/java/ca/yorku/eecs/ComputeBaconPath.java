package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Transaction;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

public class ComputeBaconPath implements HttpHandler {

    private static final String KEVIN_BACON_ID = "nm0000102"; // Kevin Bacon ID

    public ComputeBaconPath() {}

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("GET")) { //Only for GET request
                String requestBody = Utils.convert(r.getRequestBody());
                String[] result = handleGet(requestBody);
                int statusCode = Integer.parseInt(result[0]); // Get the status code from the result
                String response = result[1]; // Get the response body from the result
                r.sendResponseHeaders(statusCode, response.length());

                // Write the response body back to the client
                try (OutputStream os = r.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                r.sendResponseHeaders(404, -1); // Send status code 404 if the request is not a GET
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the GET request to compute the Bacon Path
     * @param requestBody String representing the HTTP request body
     * @return String[] containing the status code and response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public String[] handleGet(String requestBody) throws IOException, JSONException {
        
        String actorId = "";
        JSONObject deserialized = new JSONObject(requestBody);
        if (deserialized.has("actorId")) { // If actorId was provided
            actorId = deserialized.getString("actorId");
        } else {
            return new String[] {"400", ""}; // Return 400 if actorId is not provided
        }

        String response = "";
        int statusCode;

        // Edge case: If the actorId is Kevin Bacon's own ID, return just his ID
        if (KEVIN_BACON_ID.equals(actorId)) {
            JSONArray baconPath = new JSONArray();
            baconPath.put(KEVIN_BACON_ID);
            JSONObject res = new JSONObject();
            res.put("baconPath", baconPath);
            response = res.toString();
            statusCode = 200;
            return new String[] {String.valueOf(statusCode), response};
        }

        try (Session session = Utils.driver.session()) { // Create a session
            try (Transaction tx = session.beginTransaction()) { // Create a transaction
                StatementResult result = tx.run(
                    "MATCH p = shortestPath((a:actor {actorId: $actorId})-[:ACTED_IN*]-(b:actor {actorId: $kevinBaconId})) "
                    + "RETURN [n IN nodes(p) | CASE WHEN n:actor THEN n.actorId ELSE n.movieId END] AS baconPath",
                    parameters("actorId", actorId, "kevinBaconId", KEVIN_BACON_ID) // Cypher query
                );

                if (result.hasNext()) {
                    Record record = result.next();
                    JSONArray baconPath = new JSONArray(record.get("baconPath").asList()); // We render the baconPath as a list
                    JSONObject res = new JSONObject();
                    res.put("baconPath", baconPath);
                    response = res.toString();
                    statusCode = 200; // If properly received then return 200
                } else {
                    statusCode = 404; // No path to Kevin Bacon so return 404
                    response = "";
                }
                tx.success();
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage()); //Pritn the log
            statusCode = 500;
            response = e.getMessage();
        }

        return new String[] {String.valueOf(statusCode), response};
    }
}
