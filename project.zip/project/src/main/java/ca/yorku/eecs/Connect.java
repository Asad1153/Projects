package ca.yorku.eecs;

import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Config;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;



public class Connect {
	
	   private Driver driver;
	   private String uriDb;
	   
	   //add db name and password as parameters in the constructor
	   public Connect () {
		   uriDb = "bolt://localhost:7687";
	       Config config = Config.builder().withoutEncryption().build();
	       driver = GraphDatabase.driver(uriDb, AuthTokens.basic("neo4j", "12345678"), config);
	   }
	     
	// Getter for the Driver
	    public Driver getDriver() {
	        return driver;
	    }

	    // Getter for the uriDb
	    public String getUriDb() {
	        return uriDb;
	    }
	    

}
