package ca.yorku.eecs;

import java.io.IOException;
import java.io.OutputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Record;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import static org.neo4j.driver.v1.Values.parameters;

/**
 * This class handles HTTP GET requests to filter movies by a specified minimum duration
 */
public class FilterByDuration implements HttpHandler {

    public FilterByDuration() {}

    @Override
    public void handle(HttpExchange r) {
        try {
            if (r.getRequestMethod().equals("GET")) { //For get requests
                handleGet(r);
            } else {
                r.sendResponseHeaders(404, -1); //If any other request return 404
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles the GET request to filter movies by minimum duration
     * @param r HttpExchange object representing the HTTP request and response
     * @throws IOException if there is an issue with the request or response
     * @throws JSONException if there is an issue parsing the JSON from the request
     */
    public void handleGet(HttpExchange r) throws IOException, JSONException {
        
        String body = Utils.convert(r.getRequestBody()); //Get body in json
        JSONObject deserialized = new JSONObject(body);

        String minDuration = null;
        if (deserialized.has("minDuration")) {
            minDuration = deserialized.getString("minDuration"); //Check if minimum duration has been provided if syntax or error send 400
        } else {
            r.sendResponseHeaders(400, -1);
            return;
        }

        String response = null;
        int statusCode;

        try (Session session = Utils.driver.session()) { //Start session
            String query;
            query = "MATCH (m:movie) WHERE m.duration >= toInteger($minDuration) "
                  + "RETURN {movieId: m.movieId, name: m.name, duration: m.duration} AS res ORDER BY m.duration DESC"; //Cypher query

            StatementResult result = session.run(query, parameters("minDuration", minDuration)); //Do the query with the parameter

            JSONArray movies = new JSONArray();
            while (result.hasNext()) {
                Record record = result.next();
                JSONObject movie = new JSONObject(record.get("res").asMap());
                movies.put(movie);
            }

            if (movies.length() > 0) {
                response = movies.toString(); //if Movie exists return 200 else 400
                statusCode = 200;
            } else {
                statusCode = 404;
                response = "";
            }
        } catch (Exception e) {
            System.err.println("Caught Exception: " + e.getMessage());
            statusCode = 500;
            response = e.getMessage();
        }

        r.sendResponseHeaders(statusCode, response.length());
        OutputStream os = r.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}
