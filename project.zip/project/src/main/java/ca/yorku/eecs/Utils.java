package ca.yorku.eecs;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;
import org.neo4j.driver.v1.Driver;

// Utility class for functions that can be useful
public class Utils {
    public static Driver driver;

    public static String convert(InputStream inputStream) throws IOException {
        try (Scanner scanner = new Scanner(inputStream, "UTF-8")) {
            return scanner.useDelimiter("\\A").next();
        }
    }
    

}
